import smtplib,os
import tableauserverclient as TSC
import csv
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email import encoders
from email.mime.text import MIMEText


with open('.//config.txt','r') as file:
    data=file.read()
    server_url=str(data.split("server_url=")[1].split("\n")[0])
    site=str(data.split("site=")[1].split("\n")[0])
    mytoken_name=str(data.split("mytoken_name=")[1].split("\n")[0])
    mytoken_secret=str(data.split("mytoken_secret=")[1].split("\n")[0])
    smtp_server=str(data.split("smtp_server=")[1].split("\n")[0])
    smtp_port=str(data.split("smtp_port=")[1].split("\n")[0])
    email_from=str(data.split("email_from=")[1].split("\n")[0])
    email_to=str(data.split("email_to=")[1].split("\n")[0])

print(smtp_server, smtp_port)



tableau_auth = TSC.PersonalAccessTokenAuth(mytoken_name,mytoken_secret,site)

server = TSC.Server(server_url, use_server_version=True)
server.add_http_options({'verify': False})
print('Connection Success')
with server.auth.sign_in_with_personal_access_token(tableau_auth):
    print('[Logged in successfully to {}]'.format(server_url))
    print('[Loading Views to download CSV...]')        
    
    tableauVIEW = []
    for view in TSC.Pager(server.views.get):
        tableauVIEW.append(
            (   view.id
                ,view.name
                ,view.owner_id
                ,view.content_url
                ,view.project_id
        ))

    view_id = None
   
    with open('./views-input-list.csv', 'r') as testfile:

        writer = csv.DictReader(testfile,delimiter=',')

        for lines in writer:
            for vw in tableauVIEW:
                if lines ['yes_no'] == 'y':
                    content_url = lines['viewname']
                    #if not view_id is None:
                    if content_url==vw[3]:
                        print ("Lines from csv:="+lines['viewname'])
                        print("View_id:="+vw[0])
                        print("View_name:="+vw[1])
                        print("content_url:="+vw[3])
                        view = server.views.get_by_id(vw[0])
                        state = server.views.populate_csv(view)
                        import os
                        with open(os.path.join('./download',vw[1]+'.csv'),'wb') as f:
                            f.write(b''.join(view.csv))

                        print("[The data of View: {0} was downloaded as csv.]".format(vw[1]))    
        
server.auth.sign_out()



###Email with attachements#####
# create message object instance
msg = MIMEMultipart()

# setup the parameters of the message


password = ""
message = """
Subject: Report data 

Please find attached the report"""
msg['From'] = email_from
msg['To'] = email_to
msg['Subject'] = "subject of the email"

# attach the file to the message
path = "./download"
#########
attachments = os.listdir(path)
if 'attachments' in globals() and len(attachments) >= 1: # are there attachments?
        for filename in attachments:
            if os.path.isfile(os.path.join(path, filename)):
        
                f = os.path.join(path, filename)
                part = MIMEBase('application', "octet-stream")
                part.set_payload( open(f,"rb").read() )
                encoders.encode_base64(part)
                part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(f))
                print('Attachment '+filename)
                msg.attach(part)
            


# create server


server = smtplib.SMTP(smtp_server, smtp_port)
server.sendmail(msg['From'], msg['To'], msg.as_string())




server.quit()

print("Email sent!")


